 var cors = require('cors');
var fs = require('fs');
var parser = require('body-parser');
 var MongoClient = require('mongodb').MongoClient
 var data = require('./emp.json')
 MongoClient.connect("mongodb://localhost:27017/test", function (err, dbEmp) {

 var newEmp={
      "empId": 1008,
      "empName": "Sony",
      "empSalary": 120032,
      "empAddress": {
        "city": "Kanchi",
        "state": "TamilNadu"
      }}
        var emp = dbEmp.db('test');

        emp.collection('Employees').insert(newEmp, true, function (err, res) {
            if (err) throw err;
            console.log("Employee Details Added");
            dbEmp.close();
        });
    });