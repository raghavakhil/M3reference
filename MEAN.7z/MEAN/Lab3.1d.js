var express=require('express');
var exp=express();
var fs = require('fs');

exp.get('/insert',function(req,res){
  var d=fs.readFileSync('emp.json');
  var data=JSON.parse(d);
 var newEmp={
      "empId": 1007,
      "empName": "Tania",
      "empSalary": 87000,
      "empAddress": {
        "city": "Hyderabad",
        "state": "Telangana"
      }}
data.push(newEmp);
res.send(data)
fs.writeFileSync('emp.json',JSON.stringify(data))

})

exp.listen(3002, () => console.log('RUNNING........'))
