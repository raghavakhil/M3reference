var Prod=require('./lib/add');
console.log("Welcome to Node Js");
var proOne=new Prod.products(1,'pen',13);
var proTwo=new Prod.products(2,'pencil',8);
var proThree=new Prod.products(3,'book',25);
Prod.setData(proOne);
Prod.setData(proTwo);
Prod.setData(proThree);
Prod.display();
Prod.result();
var buff=new Buffer(4);
buff.write("Cap");

console.log(buff.toJSON());
var event=require('events');//Core module of node

var eve=new event.EventEmitter();
//register of event --name
eve.on("name",function(id,id1){
    console.log("Hii",id,id1);
    setTimeout(function(){
        console.log("After set time out for 4 seconds")
    },4000);
});

eve.on("price",function(temp){
    console.log("In price event",temp);
})

eve.emit("name","Akhil","This is Node");
eve.emit("price","Node JS");