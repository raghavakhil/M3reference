var MongoClient = require('mongodb').MongoClient
MongoClient.connect("mongodb://localhost:27017/cgdb", function (err, dbvar) {

        var coll = dbvar.db('cgdb');
        var temp={"productID":"15"};
        coll.collection('prod').deleteOne(temp, function (err, res) {
            if (err) throw err;
            console.log("Data deleted based on ProductID");
            console.log(res);
            dbvar.close();
        });
    });
