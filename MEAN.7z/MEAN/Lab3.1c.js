var express=require('express');
var exp=express();
var fs = require('fs');

exp.get('/update',function(req,res){
  var d=fs.readFileSync('emp.json');
  var data=JSON.parse(d);
 var a=new Array();
 var b=0;
  for(var i of data){
      if(i.empAddress.state=="Uttar Pradesh"){
          i.empAddress.city="Varanasi"
          fs.writeFileSync('emp.json',JSON.stringify(data))
          console.log(i);
          a[b]=i;
          b++;
      }

  }
res.send(a)
})

exp.listen(3002, () => console.log('RUNNING........'))
