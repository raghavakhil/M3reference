/*******************Fetching based on ID*********/
var MongoClient = require('mongodb').MongoClient
MongoClient.connect("mongodb://localhost:27017/cgdb", function (err, dbvar) {

        var coll = dbvar.db('cgdb');
        var temp={"productID":"12"};
        coll.collection('prod').find(temp).toArray( function (err, res) {
            if (err) throw err;
            console.log("Data Fetched based on ProductID");
            console.log(res);
            dbvar.close();
        });
    });
