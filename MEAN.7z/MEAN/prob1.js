
var empArray=[];

empArray.push("Akhil","Lavith","Rahul","Kiran","Deepthi","Naveen");
for(var i in empArray)
{
    console.log(empArray[i]);
}