var express=require('express');
var exp=express();
var fs = require('fs');

exp.get('/get/Maharashtra',function(req,res){
  var d=fs.readFileSync('emp.json');
  var data=JSON.parse(d);
 var a=new Array();
 var b=0;
  for(var i of data){
      if(i.empAddress.state=="Maharashtra"){
          console.log(i);
          a[b]=i;
          b++;
      }

  }
res.send(a)
})
exp.get('/get/UttarPradesh',function(req,res){
  var d=fs.readFileSync('emp.json');
  var data=JSON.parse(d);
 var a=new Array();
 var b=0;
  for(var i of data){
      if(i.empAddress.state=="Uttar Pradesh"){
          console.log(i);
          a[b]=i;
          b++;
      }

  }
res.send(a)
})
exp.get('/get/California',function(req,res){
  var d=fs.readFileSync('emp.json');
  var data=JSON.parse(d);
 var a=new Array();
 var b=0;
  for(var i of data){
      if(i.empAddress.state=="California"){
          console.log(i);
          a[b]=i;
          b++;
      }

  }
res.send(a)
})
exp.listen(3002, () => console.log('RUNNING........'))
