var express = require('express');
var exp = express();
var MongoClient = require('mongodb').MongoClient;
var url = "mongodb://localhost:27017/";
exp.get('/sel/:state', function (req, res) {
    
    MongoClient.connect(url, function (err, dbEmp) {
        if (err) throw err;
        var emp = dbEmp.db("test");
        console.log(req.params['state'] );
        var selData = { "empAddress.state": req.params['state'] };
        emp.collection("Employees").find(selData).toArray(function (err, res) {
console.log("selected data based on state ");
            console.log(res);
            dbEmp.close();
        });
    });
});
exp.listen(3002);