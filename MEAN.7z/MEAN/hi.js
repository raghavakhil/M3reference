var http=require('http');
http.createServer(function(req,res)
{
    res.writeHead(200,{'Content-Type':'text/html'});
    res.write("<h1>Hiiiii</h1>");
    res.end();
}).listen(3000);

var http=require('http')
var x=(req,res)=>{
    res.writeHead(200,{'Content-Type':'text/plain'});
    res.write("Hi Node.js");
    res.end();
}
http.createServer(x).listen(3002);


http.createServer( function(request, response) {

  response.writeHead(200,{'content-Type':'text/json'});

  var people = [
    { name: 'Dave', location: 'Atlanta' },
    { name: 'Santa Claus', location: 'North Pole' },
    { name: 'Man in the Moon', location: 'The Moon' }
  ];

  var peopleJSON = JSON.stringify(people);

  response.write(peopleJSON);
}).listen(3003);

var http=require('http');
var express=require('express');

   var exp=express();
   var x=exp.get('/save',function(req,res){
       res.writeHead(200,{'Content-Type':'text/html'});
       res.write("<h1>Express</h1>"+req.query.id*10);
       res.end("\nHalt");
   }).listen(3001);