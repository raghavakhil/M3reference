var express = require('express');
var exp = express();
var MongoClient = require('mongodb').MongoClient;
exp.get('/updatecity/:city',function(req,res) {


    MongoClient.connect("mongodb://localhost:27017/test", function (err, dbEmp) {
        if (err) throw err;

        var emp = dbEmp.db('test');
          var selCity = { "empAddress.city": req.params['city'] };
        var newData = { $set: {"empAddress.city":"Delhi" } };
        emp.collection("Employees").updateOne(selCity, newData, function (err, res) {
            if (err) throw err;
            console.log("1 document updated")
            dbEmp.close();
        });
    });
})
exp.listen(3002);