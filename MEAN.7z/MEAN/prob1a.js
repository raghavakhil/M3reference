var http = require('http');
var fs = require('fs');
http.createServer(function (req, res) {
  fs.readFile('read.txt', function(err, data) {
    console.log(data.toString());

  });
}).listen(4000);