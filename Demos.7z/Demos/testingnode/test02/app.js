module.exports={
    sayHello:function(){
        return 'hello';
    },
    addNumber:function(numOne,numTwo){
        return numOne+numTwo;
    }
}