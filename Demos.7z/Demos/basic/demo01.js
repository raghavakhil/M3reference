
function getData(name){
	console.log("hello Node"+name);
}

getData("capgemini");