var server=require('./server');
var router=require('./router');
var handler=require('./headler');
var handle={};
handle["/home"]=handler.home;
handle["/review"]=handler.review;
server.startserver(router.route,handle);