function home(){
    console.log('Handling home');
}

function review(){
    console.log('Handling review');
}

exports.home=home;
exports.review=review;