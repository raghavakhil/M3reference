var mongodb=require('mongodb');

var MongoClient=mongodb.MongoClient;
var url='mongodb://localhost/mobile';
MongoClient.connect(url,function(err,client){
if(err){
    console.log(err);
}else{
    console.log('Connection establish....'+url);
    var db=client.db('mobile');
    var collection=db.collection('mobiledata');
    
    collection.remove({'mobid':1001},function(err,res){
        if(err){
            console.log(err);
        }else{
            console.log('%s',res);
        }
    });
   
}
});