const eve=require('events');
const EventDemo=require('./logger');
const logger=new EventDemo();

//Register a listner
logger.on('message',function(msg){
	console.log('In Event listner',msg);
});

logger.getLog('capgemini');




