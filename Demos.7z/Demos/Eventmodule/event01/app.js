const eve=require('events');
const emitter=new eve.EventEmitter();

//Register a listner
emitter.on('message',function(msg){
	console.log('In Event listner',msg);
});

//Raise an event
emitter.emit('message',{id:1001,name:"Rahul"});
