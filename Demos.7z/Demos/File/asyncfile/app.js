const fs=require('fs');

fs.readFile('readMe.txt','utf-8',function(err,data)//async-Read call-non Blocking code give next line
{
	if(err){
		console.write("Problem in reading File");
	}else{
		fs.writeFile('writeMe.txt',data,function(err)//async-Write call-non Blocking code  give next line unless finish
		{
			if (err)
				return console.log(err);
		});
		}
});
console.log("ASYNC CALL");


